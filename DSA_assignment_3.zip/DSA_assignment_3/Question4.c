/*4.	Write a program to check whether a given expression is balanced or not using a stack implemented with an array.*/
#include <stdio.h>
#define MAX 100
char stack[MAX];
int top = -1;

void push(char ch) {
    stack[++top] = ch;
}
char pop() {
    if(top == -1)
        return '\0';
    return stack[top--];
}
int isBalanced(char exp[]) {
    int i;
    for(i = 0; exp[i] != '\0'; i++) {
        if(exp[i] == '(' || exp[i] == '{' || exp[i] == '[')
            push(exp[i]);

        else if(exp[i] == ')' || exp[i] == '}' || exp[i] == ']') {
            if(top == -1)
                return 0;

            char ch = pop();

            if((exp[i] == ')' && ch != '(') ||
               (exp[i] == '}' && ch != '{') ||
               (exp[i] == ']' && ch != '['))
                return 0;
        }
    }

    return (top == -1);
}

int main() {
    char exp[100];

    printf("Enter expression: ");
    gets(exp);

    if(isBalanced(exp))
        printf("Balanced Expression\n");
    else
        printf("Not Balanced\n");

    return 0;
}