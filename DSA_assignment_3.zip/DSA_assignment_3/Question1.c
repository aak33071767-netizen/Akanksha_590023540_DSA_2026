/*1.	Write a C program to implement a Stack data structure using an array. The program should be modular and use separate functions for each operation.
(i)	Insert (Push): Add an element to the top of the stack.
(ii)	Delete (Pop): Remove an element from the top of the stack.
(iii)	Display: Display all elements of the stack from top to bottom.
*/
#include <stdio.h>
#define MAX 5   

int stack[MAX];
int top = -1;   
void push(int value) {
    if (top == MAX - 1) {
        printf("Stack Overflow\n");
    } else {
        top++;
        stack[top] = value;
    }
}

void pop() {
    if (top == -1) {
        printf("Stack Underflow\n");
    } else {
        printf("Deleted element: %d\n", stack[top]);
        top--;
    }
}

void display() {
    if (top == -1) {
        printf("Stack is empty\n");
    } else {
        for (int i = top; i >= 0; i--) {
            printf("%d\n", stack[i]);
        }
    }
}

int main() {
    push(10);
    push(20);
    push(30);

    display();

    pop();
    display();

    return 0;
}
