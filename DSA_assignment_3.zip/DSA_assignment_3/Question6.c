/*6.	Write a C program to evaluate a postfix expression using a stack implemented with an array. 
(i)	Postfix Expression: 23*54*+9-
(ii)	Result = 17
*/
#include <stdio.h>
#include <ctype.h>
#define MAX 100

int stack[MAX];
int top = -1;

void push(int val) {
    stack[++top] = val;
}

int pop() {
    return stack[top--];
}
int main() {
    char postfix[] = "23*54*+9-";
    int i;

    for(i = 0; postfix[i] != '\0'; i++) {

        // If operand
        if(isdigit(postfix[i])) {
            push(postfix[i] - '0');
        }

        else {
            int val2 = pop();
            int val1 = pop();

            switch(postfix[i]) {
                case '+': push(val1 + val2); break;
                case '-': push(val1 - val2); break;
                case '*': push(val1 * val2); break;
                case '/': push(val1 / val2); break;
            }
        }
    }

    printf("Result = %d\n", pop());

    return 0;
}