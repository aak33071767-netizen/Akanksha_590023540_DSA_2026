/*2.	Write a C program to implement a Stack using a Linked List. The program should support the following operations using separate functions:
(i)	Push (Insert): Insert an element into the stack.
(ii)	Pop (Delete): Remove an element from the stack.
(iii)	Display: Display all elements of the stack.
*/

#include <stdio.h>
#include <stdlib.h>
struct Node {
    int data;
    struct Node* next;
};
struct Node* top = NULL;
void push(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->next = top;
    top = newNode;
}
void pop() {
    if (top == NULL) {
        printf("Stack Underflow\n");
    } else {
        struct Node* temp = top;
        printf("Deleted element: %d\n", top->data);
        top = top->next;
        free(temp);
    }
}
void display() {
    struct Node* temp = top;
    while (temp != NULL) {
        printf("%d\n", temp->data);
        temp = temp->next;
    }
}
int main() {
    push(10);
    push(20);
    push(30);

    display();

    pop();
    display();

    return 0;
}
