/*Write a C program using structure and dynamic memory allocation to sort student record based on marks.*/


#include <stdio.h>
#include <stdlib.h>

struct student {
    int roll;
    float marks;
};

int main() {
    int n, i, j;
    printf("Enter number of students: ");
    scanf("%d", &n);

    struct student *s = (struct student*) malloc(n*sizeof(struct student));

    for(i=0;i<n;i++){
        printf("Enter roll and marks:\n");
        scanf("%d %f",&s[i].roll,&s[i].marks);
    }

    // sorting
    for(i=0;i<n-1;i++){
        for(j=i+1;j<n;j++){
            if(s[i].marks > s[j].marks){
                struct student temp = s[i];
                s[i] = s[j];
                s[j] = temp;
            }
        }
    }

    printf("Sorted by marks:\n");
    for(i=0;i<n;i++)
        printf("%d %.2f\n", s[i].roll, s[i].marks);

    free(s);
    return 0;
}
