/*Write a C program using array of structures with dynamic memory allocation to store employee details and find the employee with the highest salary.*/

       
  #include <stdio.h>
#include <stdlib.h>

struct emp {
    int id;
    char name[20];
    float salary;
};

int main() {
    int n, i, maxIndex=0;

    printf("Enter number of employees: ");
    scanf("%d", &n);

    struct emp *e = (struct emp*) malloc(n * sizeof(struct emp));

    for(i=0;i<n;i++){
        printf("Enter id, name, salary:\n");
        scanf("%d %s %f",&e[i].id,e[i].name,&e[i].salary);
    }

    for(i=1;i<n;i++){
        if(e[i].salary > e[maxIndex].salary)
            maxIndex = i;
    }

    printf("Highest Salary Employee:\n");
    printf("%d %s %.2f", e[maxIndex].id, e[maxIndex].name, e[maxIndex].salary);

    free(e);
    return 0;
}
