/*Write a menu-driven C program using structure and dynamic memory allocation to add, display, delete records and free memory before exit.*/


#include <stdio.h>
#include <stdlib.h>

struct data
{
    int id;
};

int main()
{
    struct data *p=NULL;
    int ch,n=0;

    do
    {
        printf("\n1 Add\n2 Show\n3 Exit\n");
        scanf("%d",&ch);

        if(ch==1)
        {
            n++;
            p=realloc(p,n*sizeof(struct data));
            scanf("%d",&p[n-1].id);
        }
        else if(ch==2)
        {
            for(int i=0;i<n;i++)
                printf("%d ",p[i].id);
        }

    }while(ch!=3);

    free(p);
    return 0;
}
