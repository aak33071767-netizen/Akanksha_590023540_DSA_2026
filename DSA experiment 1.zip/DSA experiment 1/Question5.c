/*Write a C program using structure and dynamic memory allocation to store and display student details such as roll number, name, and marks.*/

            
              #include <stdio.h>
#include <stdlib.h>

struct student
{
    int roll;
    char name[20];
    float marks;
};

int main()
{
    struct student *s;

    s = (struct student*)malloc(sizeof(struct student));

    printf("Enter roll name marks:\n");
    scanf("%d %s %f",&s->roll,s->name,&s->marks);

    printf("Roll = %d\n",s->roll);
    printf("Name = %s\n",s->name);
    printf("Marks = %.2f",s->marks);

    free(s);
    return 0;
}
