/*Write a C program to show the difference in memory allocation between structure and union using sizeof().*/

 
#include <stdio.h>

struct s {
    int i;
    float f;
    char c;
};

union u {
    int i;
    float f;
    char c;
};

int main() {
    printf("Size of structure = %lu\n", sizeof(struct s));
    printf("Size of union = %lu\n", sizeof(union u));
    return 0;
}
