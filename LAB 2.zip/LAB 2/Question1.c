/*Suppose there are 20 Students in a class
Enter the marks of the student in an array.(Max=100)
Print total marks of each other*/

#include <stdio.h>

int main() {
    int marks[20][2];   
    int i;

    printf("Enter marks of 20 students (2 subjects each, out of 100):\n");

    for (i = 0; i < 20; i++) {
        printf("Student %d Subject 1 & 2: ", i + 1);
        scanf("%d %d", &marks[i][0], &marks[i][1]);
    }

    printf("\nTotal marks of each student:\n");

    for (i = 0; i < 20; i++) {
        int total = marks[i][0] + marks[i][1];
        printf("Student %d Total = %d\n", i + 1, total);
    }

    return 0;
}
