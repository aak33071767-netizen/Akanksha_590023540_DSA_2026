/*5.	Write a C program to implement a Stack using two Queues. The queues must be implemented using arrays, and all operations should be performed using functions.
(i)	Push: Insert an element into the stack.
(ii)	Pop: Remove the top element from the stack.
(iii)	 Peek: Display the top element without removing it.
(iv)	 isEmpty: Check whether the stack is empty.
(v)	Display: Print all elements of the stack.
*/
#include <stdio.h>
#define SIZE 5
int q1[SIZE], q2[SIZE];
int front1 = -1, rear1 = -1;
int front2 = -1, rear2 = -1;
void enqueue1(int x) {
    if (rear1 == SIZE - 1) return;
    if (front1 == -1) front1 = 0;
    q1[++rear1] = x;
}
int dequeue1() {
    return q1[front1++];
}
void push(int x) {
    enqueue1(x);
}
void pop() {
    if (front1 == -1 || front1 > rear1) {
        printf("Stack empty\n");
        return;
    }
    while (front1 < rear1) {
        q2[++rear2] = dequeue1();
    }
    printf("Popped: %d\n", dequeue1());
    for (int i = 0; i <= rear2; i++)
        q1[i] = q2[i];

    front1 = 0;
    rear1 = rear2;
    front2 = rear2 = -1;
}
void peek() {
    if (front1 == -1 || front1 > rear1)
        printf("Stack empty\n");
    else
        printf("Top: %d\n", q1[rear1]);
}
void display() {
    for (int i = front1; i <= rear1; i++)
        printf("%d ", q1[i]);
    printf("\n");
}
int main() {
    push(10);
    push(20);
    push(30);
    display();
    pop();
    peek();
    display();
}