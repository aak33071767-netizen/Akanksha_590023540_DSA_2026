/*3.	Write a program to check whether a given string is a palindrome or not using an Array and a Queue data structure.*/
#include <stdio.h>
#include <string.h>
int main() {
    char str[50];
    char queue[50];
    int front = 0, rear = -1;

    printf("Enter string: ");
    scanf("%s", str);

    int len = strlen(str);
    for (int i = 0; i < len; i++) {
        queue[++rear] = str[i];
    }
    int flag = 1;
    for (int i = len - 1; i >= 0; i--) {
        if (queue[front++] != str[i]) {
            flag = 0;
            break;
        }
    }

    if (flag)
        printf("Palindrome\n");
    else
        printf("Not Palindrome\n");
}