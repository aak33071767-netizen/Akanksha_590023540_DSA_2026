/*2.	Write a C program to implement a Queue using a Linked List. The program should support the following operations using separate functions:
(i)	Enqueue (Insert): Insert an element into the Queue.
(ii)	Dequeue (Delete): Remove an element from the Queue.
(iii)	Display: Display all elements of the Queue.
(iv)	Peek: Display the front element of the Queue.
*/
#include <stdio.h>
#include <stdlib.h>
struct node {
    int data;
    struct node* next;
};
struct node *front = NULL, *rear = NULL;
void enqueue(int value) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->data = value;
    temp->next = NULL;

    if (rear == NULL) {
        front = rear = temp;
    } else {
        rear->next = temp;
        rear = temp;
    }
}
void dequeue() {
    if (front == NULL) {
        printf("Queue Underflow\n");
        return;
    }
    struct node* temp = front;
    printf("Deleted: %d\n", temp->data);
    front = front->next;
    free(temp);
}
void peek() {
    if (front == NULL)
        printf("Queue is empty\n");
    else
        printf("Front: %d\n", front->data);
}
void display() {
    struct node* temp = front;
    while (temp != NULL) {
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}
int main() {
    enqueue(5);
    enqueue(15);
    enqueue(25);
    display();
    dequeue();
    peek();
    display();
}