/*Creat a linklist*/

#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

int main()
{
    struct node *start = NULL, *ptr = NULL, *newnode = NULL;
    int choice = 1, count = 0;

    while(choice)
    {
        newnode = (struct node*)malloc(sizeof(struct node));
        printf("Enter data: ");
        scanf("%d", &newnode->data);

        newnode->next = NULL;

        if(start == NULL)
        {
            start = newnode;
        }
        else
        {
            ptr = start;
            while(ptr->next != NULL)
            {
                ptr = ptr->next;
            }
            ptr->next = newnode;
        }

        count++;
        printf("Do you want to continue? (1/0): ");
        scanf("%d", &choice);
    }

    printf("Total nodes = %d", count);

    return 0;
}
