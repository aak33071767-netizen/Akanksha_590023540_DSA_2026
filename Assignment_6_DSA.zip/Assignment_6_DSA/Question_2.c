/*2.	Write a C program to implement a Binary Heap (Min Heap or Max Heap). The program should support the following operations:
(i)	Heap Creation: Initialize an empty heap using an array.
(ii)	Insertion (Heapify-Up): Insert a new element into the heap. Maintain the heap property using heapify-up operation.
(iii)	 Deletion (Heapify-Down): Delete the root element (minimum in Min Heap / maximum in Max Heap). Maintain heap property using heapify-down operation.
(iv)	 Display Heap: Print the elements of the heap.
*/
#include <stdio.h>

#define MAX 100
int heap[MAX], size = 0;

void swap(int *a, int *b) {
    int t = *a; *a = *b; *b = t;
}

void heapifyUp(int i) {
    while (i > 0 && heap[(i-1)/2] > heap[i]) {
        swap(&heap[i], &heap[(i-1)/2]);
        i = (i-1)/2;
    }
}

void insert(int val) {
    heap[size] = val;
    heapifyUp(size);
    size++;
}

void heapifyDown(int i) {
    int smallest = i;
    int left = 2*i+1, right = 2*i+2;

    if (left < size && heap[left] < heap[smallest])
        smallest = left;
    if (right < size && heap[right] < heap[smallest])
        smallest = right;

    if (smallest != i) {
        swap(&heap[i], &heap[smallest]);
        heapifyDown(smallest);
    }
}

void deleteRoot() {
    if (size == 0) return;
    heap[0] = heap[size-1];
    size--;
    heapifyDown(0);
}

void display() {
    for (int i = 0; i < size; i++)
        printf("%d ", heap[i]);
    printf("\n");
}

int main() {
    int ch, val;

    while (1) {
        printf("\n1.Insert 2.Delete Root 3.Display 4.Exit\n");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &val);
                insert(val);
                break;

            case 2:
                deleteRoot();
                break;

            case 3:
                display();
                break;

            case 4:
                return 0;
        }
    }
}