/*3.	Write a C program to implement a Priority Queue using a Binary Heap (Min Heap or Max Heap). The program should support the following operations:
(i)	Insert (Enqueue with Priority): Insert an element along with its priority into the queue. Maintain heap property using heapify-up.
(ii)	Delete (Dequeue Highest Priority Element): Remove the element with the highest priority: (Min Heap → smallest element) and (Max Heap → largest element). Maintain heap property using heapify-down.
(iii)	 Peek: Display the element with the highest priority without removing it.
(iv)	 Display: Print all elements of the priority queue.
*/
#include <stdio.h>

#define MAX 100
int pq[MAX], size = 0;

void swap(int *a, int *b) {
    int t = *a; *a = *b; *b = t;
}

void heapifyUp(int i) {
    while (i > 0 && pq[(i-1)/2] > pq[i]) {
        swap(&pq[i], &pq[(i-1)/2]);
        i = (i-1)/2;
    }
}

void enqueue(int val) {
    pq[size] = val;
    heapifyUp(size);
    size++;
}

void heapifyDown(int i) {
    int smallest = i;
    int left = 2*i+1, right = 2*i+2;

    if (left < size && pq[left] < pq[smallest])
        smallest = left;
    if (right < size && pq[right] < pq[smallest])
        smallest = right;

    if (smallest != i) {
        swap(&pq[i], &pq[smallest]);
        heapifyDown(smallest);
    }
}

void dequeue() {
    if (size == 0) return;
    printf("Removed: %d\n", pq[0]);
    pq[0] = pq[size-1];
    size--;
    heapifyDown(0);
}

void peek() {
    if (size > 0)
        printf("Top: %d\n", pq[0]);
}

void display() {
    for (int i = 0; i < size; i++)
        printf("%d ", pq[i]);
    printf("\n");
}

int main() {
    int ch, val;

    while (1) {
        printf("\n1.Enqueue 2.Dequeue 3.Peek 4.Display 5.Exit\n");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &val);
                enqueue(val);
                break;

            case 2:
                dequeue();
                break;

            case 3:
                peek();
                break;

            case 4:
                display();
                break;

            case 5:
                return 0;
        }
    }
}