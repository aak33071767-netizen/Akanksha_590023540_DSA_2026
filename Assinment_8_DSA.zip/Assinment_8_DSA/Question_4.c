/*4.	Write a C program to implement the Merge Sort using recursion.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	 Requirements:
•	Clearly implement the divide and merge steps.
*/
#include <stdio.h>
 
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
// ---- MERGE step ----
// Merges two sorted sub-arrays: arr[left..mid] and arr[mid+1..right]
void merge(int arr[], int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;   // size of left half
    int n2 = right - mid;       // size of right half
 
    // Temporary arrays
    int L[n1], R[n2];
 
    // Copy data to temporary arrays
    for (i = 0; i < n1; i++) L[i] = arr[left + i];
    for (j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];
 
    printf("  Merging  : [");
    for (i = 0; i < n1; i++) printf("%d%s", L[i], i < n1-1 ? " " : "");
    printf("] and [");
    for (j = 0; j < n2; j++) printf("%d%s", R[j], j < n2-1 ? " " : "");
    printf("]\n");
 
    // Merge back into arr[]
    i = 0; j = 0; k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j])
            arr[k++] = L[i++];
        else
            arr[k++] = R[j++];
    }
    while (i < n1) arr[k++] = L[i++];
    while (j < n2) arr[k++] = R[j++];
 
    printf("  Result   : ");
    for (int x = left; x <= right; x++) printf("%d ", arr[x]);
    printf("\n\n");
}
 
// ---- DIVIDE step ----
void mergeSort(int arr[], int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;   // avoids overflow
 
        printf("Dividing : indices [%d..%d] -> left[%d..%d] right[%d..%d]\n",
               left, right, left, mid, mid + 1, right);
 
        mergeSort(arr, left, mid);       // sort left half
        mergeSort(arr, mid + 1, right);  // sort right half
        merge(arr, left, mid, right);    // merge sorted halves
    }
}
 
int main() {
    int n;
    printf("=== Merge Sort ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    printf("\nOriginal Array : ");
    printArray(arr, n);
    printf("\n--- Recursive Divide & Merge ---\n\n");
 
    mergeSort(arr, 0, n - 1);
 
    printf("Sorted Array   : ");
    printArray(arr, n);
 
    return 0;
}
