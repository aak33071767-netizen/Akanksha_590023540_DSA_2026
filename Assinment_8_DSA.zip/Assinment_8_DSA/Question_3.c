/*3.	Write a C program to implement the Insertion Sort algorithm.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	 Requirements:
•	Display the array after inserting each element.
*/
#include <stdio.h>
 
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
void insertionSort(int arr[], int n) {
    for (int i = 1; i < n; i++) {
        int key = arr[i];
        int j = i - 1;
 
        // Shift elements that are greater than key one position ahead
        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
 
        printf("After inserting element %d (arr[%d] = %d): ", i, i, key);
        printArray(arr, n);
    }
}
 
int main() {
    int n;
    printf("=== Insertion Sort ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    printf("\nOriginal Array : ");
    printArray(arr, n);
    printf("\n");
 
    insertionSort(arr, n);
 
    printf("\nSorted Array   : ");
    printArray(arr, n);
 
    return 0;
}
 