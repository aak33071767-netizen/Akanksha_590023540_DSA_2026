/*
2.	Write a C program to implement the Selection Sort algorithm.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	Requirements:
•	Display the array after each pass.
•	Count and display the total number of comparisons and swaps.
*/
#include <stdio.h>
 
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
void selectionSort(int arr[], int n) {
    int comparisons = 0, swaps = 0;
    int temp;
 
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
 
        for (int j = i + 1; j < n; j++) {
            comparisons++;
            if (arr[j] < arr[minIdx])
                minIdx = j;
        }
 
        // Swap only if a smaller element was found
        if (minIdx != i) {
            temp = arr[i];
            arr[i] = arr[minIdx];
            arr[minIdx] = temp;
            swaps++;
        }
 
        printf("After Pass %d: ", i + 1);
        printArray(arr, n);
    }
 
    printf("\nTotal Comparisons : %d\n", comparisons);
    printf("Total Swaps       : %d\n", swaps);
}
 
int main() {
    int n;
    printf("=== Selection Sort ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    printf("\nOriginal Array : ");
    printArray(arr, n);
    printf("\n");
 
    selectionSort(arr, n);
 
    printf("\nSorted Array   : ");
    printArray(arr, n);
 
    return 0;
}