/*6.	Write a C program to perform Linear Search that finds all occurrences of a given element in an array.
(i)	Input: array of size n and a key element.
(ii)	Output: all positions where the element occurs.
(iii)	 If the element does not exist, display an appropriate message.
*/
#include <stdio.h>
 
void linearSearch(int arr[], int n, int key) {
    int count = 0;
 
    printf("\nSearching for %d in the array...\n", key);
 
    for (int i = 0; i < n; i++) {
        if (arr[i] == key) {
            printf("  Found at index %d (position %d)\n", i, i + 1);
            count++;
        }
    }
 
    if (count == 0)
        printf("  Element %d NOT found in the array.\n", key);
    else
        printf("\nTotal occurrences of %d: %d\n", key, count);
}
 
int main() {
    int n;
    printf("=== Linear Search (All Occurrences) ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    int key;
    printf("Enter key to search: ");
    scanf("%d", &key);
 
    linearSearch(arr, n, key);
 
    return 0;
}