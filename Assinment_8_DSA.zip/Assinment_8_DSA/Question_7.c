/*7.	Write a C program to implement Binary Search using recursion.
(i)	Input a sorted array and a key value.
(ii)	Use a recursive function to perform the search.
(iii)	 Return and display the index of the element if found.
*/
#include <stdio.h>
 
int binarySearch(int arr[], int low, int high, int key) {
    if (low > high) {
        return -1;   // base case: search space exhausted
    }
 
    int mid = low + (high - low) / 2;   // avoids integer overflow
 
    printf("  Searching in indices [%d..%d], mid = %d, arr[mid] = %d\n",
           low, high, mid, arr[mid]);
 
    if (arr[mid] == key)
        return mid;                              // found
    else if (arr[mid] > key)
        return binarySearch(arr, low, mid - 1, key);   // search left half
    else
        return binarySearch(arr, mid + 1, high, key);  // search right half
}
 
int main() {
    int n;
    printf("=== Binary Search (Recursive) ===\n");
    printf("Enter number of elements (must be sorted): ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d sorted integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);

    int sorted = 1;
    for (int i = 0; i < n - 1; i++) {
        if (arr[i] > arr[i + 1]) { sorted = 0; break; }
    }
    if (!sorted) {
        printf("Warning: Array is NOT sorted. Binary Search requires a sorted array.\n");
    }
 
    int key;
    printf("Enter key to search: ");
    scanf("%d", &key);
 
    printf("\n--- Recursive Steps ---\n");
    int result = binarySearch(arr, 0, n - 1, key);
 
    if (result == -1)
        printf("\nElement %d NOT found in the array.\n", key);
    else
        printf("\nElement %d found at index %d (position %d).\n",
               key, result, result + 1);
 
    return 0;
}