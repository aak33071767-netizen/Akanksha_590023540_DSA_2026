/*5.	Write a C program to implement the Quick Sort using recursion.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	 Requirements:
•	Use any partitioning scheme.
*/
#include <stdio.h>
 
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

int partition(int arr[], int low, int high) {
    int pivot = arr[high];   // pivot is the last element
    int i = low - 1;         // index of smaller element
 
    printf("  Pivot = %d  | Sub-array: ", pivot);
    for (int k = low; k <= high; k++) printf("%d ", arr[k]);
    printf("\n");
 
    for (int j = low; j < high; j++) {
        if (arr[j] <= pivot) {
            i++;
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
 
    return i + 1;   // return pivot index
}
 
void quickSort(int arr[], int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
 
        printf("  After partition (pivot at index %d): ", pi);
        printArray(arr, high - low + 2);   // rough size for display
 
        quickSort(arr, low, pi - 1);   // sort left of pivot
        quickSort(arr, pi + 1, high);  // sort right of pivot
    }
}
 
int main() {
    int n;
    printf("=== Quick Sort ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    printf("\nOriginal Array : ");
    printArray(arr, n);
    printf("\n--- Partitioning Steps ---\n");
 
    quickSort(arr, 0, n - 1);
 
    printf("\nSorted Array   : ");
    printArray(arr, n);
 
    return 0;
}