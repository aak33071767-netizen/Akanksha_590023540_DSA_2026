/*1.	Write a C program to implement the Bubble Sort algorithm.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	 Requirements:
•	Display the array after each pass.
•	Count and display the total number of comparisons and swaps.
*/
#include <stdio.h>
 
void printArray(int arr[], int n) {
    for (int i = 0; i < n; i++)
        printf("%d ", arr[i]);
    printf("\n");
}
 
void bubbleSort(int arr[], int n) {
    int comparisons = 0, swaps = 0;
    int temp;
 
    for (int pass = 1; pass < n; pass++) {
        int swapped = 0;
 
        for (int j = 0; j < n - pass; j++) {
            comparisons++;
            if (arr[j] > arr[j + 1]) {
                // Swap
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
                swaps++;
                swapped = 1;
            }
        }
 
        printf("After Pass %d: ", pass);
        printArray(arr, n);
 
        // Early exit if no swap occurred in this pass
        if (!swapped) {
            printf("(Array already sorted — stopping early)\n");
            break;
        }
    }
 
    printf("\nTotal Comparisons : %d\n", comparisons);
    printf("Total Swaps       : %d\n", swaps);
}
 
int main() {
    int n;
    printf("=== Bubble Sort ===\n");
    printf("Enter number of elements: ");
    scanf("%d", &n);
 
    int arr[n];
    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++)
        scanf("%d", &arr[i]);
 
    printf("\nOriginal Array : ");
    printArray(arr, n);
    printf("\n");
 
    bubbleSort(arr, n);
 
    printf("\nSorted Array   : ");
    printArray(arr, n);
 
    return 0;
}
 