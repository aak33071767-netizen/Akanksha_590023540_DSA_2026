/*6.	Write a C program to implement a Circular Singly Linked List and perform all basic operations on it. The program must support the following operations:
•	Creation of a Circular Linked List
•	Insertion of a node (At the beginning and at the end of the list)
•	Deletion of a node (From the beginning and from the end of the list)
•	Traversal and display of the circular linked list and counting the number of nodes in the list.
*/
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

void display(struct node *head) {
    struct node *temp;
    int count = 0;

    if(head == NULL) {
        printf("List is empty\n");
        return;
    }

    temp = head;
    printf("Circular List: ");

    do {
        printf("%d ", temp->data);
        count++;
        temp = temp->next;
    } while(temp != head);

    printf("\nTotal nodes = %d\n", count);
}

int main() {
    struct node *head = NULL, *temp, *newnode, *last;
    int choice, value;

    while(1) {
        printf("\n1. Insert at Beginning");
        printf("\n2. Insert at End");
        printf("\n3. Delete from Beginning");
        printf("\n4. Delete from End");
        printf("\n5. Display");
        printf("\n6. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        if(choice == 6)
            break;

        switch(choice) {

        case 1:  // Insert at Beginning
            newnode = (struct node*)malloc(sizeof(struct node));
            printf("Enter value: ");
            scanf("%d", &newnode->data);

            if(head == NULL) {
                head = newnode;
                newnode->next = head;
            } else {
                temp = head;
                while(temp->next != head)
                    temp = temp->next;

                newnode->next = head;
                temp->next = newnode;
                head = newnode;
            }
            printf("Inserted at beginning\n");
            break;

        case 2:  // Insert at End
            newnode = (struct node*)malloc(sizeof(struct node));
            printf("Enter value: ");
            scanf("%d", &newnode->data);

            if(head == NULL) {
                head = newnode;
                newnode->next = head;
            } else {
                temp = head;
                while(temp->next != head)
                    temp = temp->next;

                temp->next = newnode;
                newnode->next = head;
            }
            printf("Inserted at end\n");
            break;

        case 3:  // Delete from Beginning
            if(head == NULL) {
                printf("List is empty\n");
            } else if(head->next == head) {
                free(head);
                head = NULL;
                printf("Deleted last node\n");
            } else {
                temp = head;
                last = head;
                while(last->next != head)
                    last = last->next;

                head = head->next;
                last->next = head;
                free(temp);
                printf("Deleted from beginning\n");
            }
            break;

        case 4:  // Delete from End
            if(head == NULL) {
                printf("List is empty\n");
            } else if(head->next == head) {
                free(head);
                head = NULL;
                printf("Deleted last node\n");
            } else {
                temp = head;
                struct node *prev;

                while(temp->next != head) {
                    prev = temp;
                    temp = temp->next;
                }

                prev->next = head;
                free(temp);
                printf("Deleted from end\n");
            }
            break;

        case 5:
            display(head);
            break;

        default:
            printf("Invalid choice\n");
        }
    }

    return 0;
}