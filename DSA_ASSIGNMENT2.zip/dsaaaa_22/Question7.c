/*7.	 Write a C program to implement a Doubly Linked List. The program should perform all basic operations on the list. The program must support the following operations:
•	Creation of a Doubly Linked List, display and counting the number of nodes
•	Insertion of a node (At the beginning, At the end, After a given node)
•	Deletion of a node (From the beginning, From the end, of a given node)
•	Traversal of the list (Forward traversal and Backward traversal)
*/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *prev,*next;
};

struct node *head=NULL;

void insertBeg(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->prev=NULL;
    newnode->next=head;

    if(head!=NULL)
        head->prev=newnode;

    head=newnode;
}

void insertEnd(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=NULL;

    if(head==NULL){
        newnode->prev=NULL;
        head=newnode;
        return;
    }

    struct node* temp=head;
    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newnode;
    newnode->prev=temp;
}

void insertAfter(){
    int key,val;
    printf("Insert after value: ");
    scanf("%d",&key);

    struct node* temp=head;
    while(temp!=NULL && temp->data!=key)
        temp=temp->next;

    if(temp==NULL){
        printf("Value not found\n");
        return;
    }

    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;

    newnode->next=temp->next;
    newnode->prev=temp;

    if(temp->next!=NULL)
        temp->next->prev=newnode;

    temp->next=newnode;
}

void deleteBeg(){
    if(head==NULL){
        printf("List empty\n");
        return;
    }

    struct node* temp=head;
    head=head->next;

    if(head!=NULL)
        head->prev=NULL;

    free(temp);
}

void deleteEnd(){
    if(head==NULL){
        printf("List empty\n");
        return;
    }

    struct node* temp=head;

    if(temp->next==NULL){
        free(temp);
        head=NULL;
        return;
    }

    while(temp->next!=NULL)
        temp=temp->next;

    temp->prev->next=NULL;
    free(temp);
}

void deleteValue(){
    int key;
    printf("Enter value to delete: ");
    scanf("%d",&key);

    struct node* temp=head;

    while(temp!=NULL && temp->data!=key)
        temp=temp->next;

    if(temp==NULL){
        printf("Value not found\n");
        return;
    }

    if(temp==head){
        deleteBeg();
        return;
    }

    if(temp->next!=NULL)
        temp->next->prev=temp->prev;

    if(temp->prev!=NULL)
        temp->prev->next=temp->next;

    free(temp);
}

void forward(){
    struct node* temp=head;
    printf("Forward: ");
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

void backward(){
    struct node* temp=head;
    if(temp==NULL) return;

    while(temp->next!=NULL)
        temp=temp->next;

    printf("Backward: ");
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->prev;
    }
    printf("\n");
}

int count(){
    int c=0;
    struct node* temp=head;
    while(temp!=NULL){
        c++;
        temp=temp->next;
    }
    return c;
}

int main(){
    int ch;

    while(1){
        printf("\n1.Insert Beg 2.Insert End 3.Insert After");
        printf("\n4.Delete Beg 5.Delete End 6.Delete Value");
        printf("\n7.Forward 8.Backward 9.Count 10.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: insertBeg(); break;
            case 2: insertEnd(); break;
            case 3: insertAfter(); break;
            case 4: deleteBeg(); break;
            case 5: deleteEnd(); break;
            case 6: deleteValue(); break;
            case 7: forward(); break;
            case 8: backward(); break;
            case 9: printf("Total Nodes = %d\n",count()); break;
            case 10: exit(0);
        }
    }
}