/*10.	Write a C program to maintain Student 
Records using a Linked List. Each node should store student details such as roll number, name, and marks. Implement operations
 to insert, delete, search, and display records.*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct student{
    int roll;
    char name[50];
    float marks;
    struct student* next;
};

struct student* head=NULL;

void insert(){
    struct student* newnode=malloc(sizeof(struct student));

    printf("Enter Roll Name Marks: ");
    scanf("%d%s%f",&newnode->roll,newnode->name,&newnode->marks);

    newnode->next=head;
    head=newnode;
}

void display(){
    struct student* temp=head;
    while(temp!=NULL){
        printf("Roll:%d Name:%s Marks:%.2f\n",
        temp->roll,temp->name,temp->marks);
        temp=temp->next;
    }
}

void search(){
    int r;
    printf("Enter roll to search: ");
    scanf("%d",&r);

    struct student* temp=head;
    while(temp!=NULL){
        if(temp->roll==r){
            printf("Found: %s %.2f\n",temp->name,temp->marks);
            return;
        }
        temp=temp->next;
    }
    printf("Not found\n");
}

void delete(){
    int r;
    printf("Enter roll to delete: ");
    scanf("%d",&r);

    struct student *temp=head,*prev=NULL;

    while(temp!=NULL && temp->roll!=r){
        prev=temp;
        temp=temp->next;
    }

    if(temp==NULL){
        printf("Not found\n");
        return;
    }

    if(prev==NULL)
        head=temp->next;
    else
        prev->next=temp->next;

    free(temp);
    printf("Deleted\n");
}

int main(){
    int ch;

    while(1){
        printf("\n1.Insert 2.Display 3.Search 4.Delete 5.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: insert(); break;
            case 2: display(); break;
            case 3: search(); break;
            case 4: delete(); break;
            case 5: exit(0);
        }
    }
}
