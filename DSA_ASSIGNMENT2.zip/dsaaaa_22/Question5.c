/*5.	Write a C program to reverse the data 
of the nodes of a singly 
linked list without changing the links between the nodes.*/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node* next;
};

struct node* head=NULL;

void insertEnd(int val){
    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=NULL;

    if(head==NULL){
        head=newnode;
        return;
    }

    struct node* temp=head;
    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newnode;
}

void display(){
    struct node* temp=head;
    printf("List: ");
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

void reverseData(){
    int arr[100],i=0,count=0;
    struct node* temp=head;

    while(temp!=NULL){
        arr[count++]=temp->data;
        temp=temp->next;
    }

    temp=head;
    for(i=count-1;i>=0;i--){
        temp->data=arr[i];
        temp=temp->next;
    }

    printf("Data reversed successfully\n");
}

int main(){
    insertEnd(1);
    insertEnd(2);
    insertEnd(3);
    insertEnd(4);
    insertEnd(5);

    printf("Before Reverse:\n");
    display();

    reverseData();

    printf("After Reverse:\n");
    display();

    return 0;
}