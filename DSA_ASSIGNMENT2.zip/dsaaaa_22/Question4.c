/*4.	Write a C program to implement deletion operations on a singly linked list. The program should support deleting an element from:
•	The beginning of the linked list
•	The end of the linked list
•	After a given node (specified by its value)
*/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node* next;
};

struct node* head=NULL;

void insertEnd(int val){
    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=NULL;

    if(head==NULL){
        head=newnode;
        return;
    }

    struct node* temp=head;
    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newnode;
}

void deleteBeg(){
    if(head==NULL){
        printf("List empty\n");
        return;
    }

    struct node* temp=head;
    head=head->next;
    free(temp);

    printf("Deleted from beginning\n");
}

void deleteEnd(){
    if(head==NULL){
        printf("List empty\n");
        return;
    }

    struct node *temp=head,*prev;

    if(head->next==NULL){
        free(head);
        head=NULL;
        printf("Deleted last node\n");
        return;
    }

    while(temp->next!=NULL){
        prev=temp;
        temp=temp->next;
    }

    prev->next=NULL;
    free(temp);

    printf("Deleted from end\n");
}

void deleteAfter(){
    int key;
    printf("Delete node after value: ");
    scanf("%d",&key);

    struct node* temp=head;

    while(temp!=NULL && temp->data!=key)
        temp=temp->next;

    if(temp==NULL || temp->next==NULL){
        printf("Cannot delete\n");
        return;
    }

    struct node* del=temp->next;
    temp->next=del->next;
    free(del);

    printf("Deleted successfully\n");
}

void display(){
    struct node* temp=head;
    printf("List: ");
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

int main(){
    int ch,val;

    /* Initial data for testing */
    insertEnd(10);
    insertEnd(20);
    insertEnd(30);

    while(1){
        printf("\n1.Delete Beg 2.Delete End 3.Delete After 4.Display 5.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: deleteBeg(); break;
            case 2: deleteEnd(); break;
            case 3: deleteAfter(); break;
            case 4: display(); break;
            case 5: exit(0);
        }
    }
}