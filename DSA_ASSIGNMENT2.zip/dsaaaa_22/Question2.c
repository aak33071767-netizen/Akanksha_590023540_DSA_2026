/*2.	Write a C program to implement a 
singly linked list and search for a given element in the list. If the element is found, display the position of the element in
 the linked list; otherwise, display element does not exit.*/
#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

int main() {
    struct node *head = NULL, *temp, *newnode;
    int n, i, key;
    int position = 1;
    int found = 0;

    printf("Enter number of nodes: ");
    scanf("%d", &n);

    // Create Linked List
    for(i = 0; i < n; i++) {
        newnode = (struct node*)malloc(sizeof(struct node));
        printf("Enter data: ");
        scanf("%d", &newnode->data);

        newnode->next = NULL;

        if(head == NULL) {
            head = newnode;
        } else {
            temp = head;
            while(temp->next != NULL) {
                temp = temp->next;
            }
            temp->next = newnode;
        }
    }

    // Search element
    printf("Enter element to search: ");
    scanf("%d", &key);

    temp = head;

    while(temp != NULL) {
        if(temp->data == key) {
            printf("Element found at position %d\n", position);
            found = 1;
            break;
        }
        temp = temp->next;
        position++;
    }

    if(found == 0) {
        printf("Element does not exist\n");
    }

    return 0;
}