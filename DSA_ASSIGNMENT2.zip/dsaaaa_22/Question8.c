/*8.	Write a C program to implement a Doubly Circular Linked List. The program should perform all basic operations on the list. The program must support the following operations:
•	Creation of a Doubly Circular Linked List, display and counting the number of nodes
•	Insertion of a node (At the beginning, At the end)
•	Deletion of a node (From the beginning, From the end)
*/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node *prev,*next;
};

struct node* head=NULL;

void insertBeg(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;

    if(head==NULL){
        newnode->next=newnode->prev=newnode;
        head=newnode;
        return;
    }

    struct node* last=head->prev;

    newnode->next=head;
    newnode->prev=last;
    last->next=newnode;
    head->prev=newnode;
    head=newnode;
}

void insertEnd(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;

    if(head==NULL){
        newnode->next=newnode->prev=newnode;
        head=newnode;
        return;
    }

    struct node* last=head->prev;

    newnode->next=head;
    newnode->prev=last;
    last->next=newnode;
    head->prev=newnode;
}

void deleteBeg(){
    if(head==NULL) return;

    if(head->next==head){
        free(head);
        head=NULL;
        return;
    }

    struct node* last=head->prev;
    struct node* temp=head;

    head=head->next;
    last->next=head;
    head->prev=last;

    free(temp);
}

void deleteEnd(){
    if(head==NULL) return;

    if(head->next==head){
        free(head);
        head=NULL;
        return;
    }

    struct node* last=head->prev;
    last->prev->next=head;
    head->prev=last->prev;

    free(last);
}

void display(){
    if(head==NULL){
        printf("Empty\n");
        return;
    }

    struct node* temp=head;
    int count=0;

    printf("List: ");
    do{
        printf("%d ",temp->data);
        temp=temp->next;
        count++;
    }while(temp!=head);

    printf("\nTotal Nodes=%d\n",count);
}

int main(){
    int ch;

    while(1){
        printf("\n1.Insert Beg 2.Insert End 3.Delete Beg 4.Delete End 5.Display 6.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: insertBeg(); break;
            case 2: insertEnd(); break;
            case 3: deleteBeg(); break;
            case 4: deleteEnd(); break;
            case 5: display(); break;
            case 6: exit(0);
        }
    }
}