/*3.	Write a C program to implement insertion operations in a singly linked list. The program should perform the following operations:
•	Insert a new element at the beginning of the linked list.
•	Insert a new element at the end of the linked list.
•	Insert a new element after a given node in the linked list.
*/
#include <stdio.h>
#include <stdlib.h>

struct node{
    int data;
    struct node* next;
};

struct node* head=NULL;

void insertBeg(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=head;
    head=newnode;

    printf("Inserted at beginning\n");
}

void insertEnd(){
    int val;
    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=NULL;

    if(head==NULL){
        head=newnode;
        return;
    }

    struct node* temp=head;
    while(temp->next!=NULL)
        temp=temp->next;

    temp->next=newnode;

    printf("Inserted at end\n");
}

void insertAfter(){
    int key,val;
    printf("Insert after which value: ");
    scanf("%d",&key);

    struct node* temp=head;
    while(temp!=NULL && temp->data!=key)
        temp=temp->next;

    if(temp==NULL){
        printf("Value not found\n");
        return;
    }

    printf("Enter value: ");
    scanf("%d",&val);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->data=val;
    newnode->next=temp->next;
    temp->next=newnode;

    printf("Inserted successfully\n");
}

void display(){
    struct node* temp=head;
    printf("List: ");
    while(temp!=NULL){
        printf("%d ",temp->data);
        temp=temp->next;
    }
    printf("\n");
}

int main(){
    int ch;

    while(1){
        printf("\n1.Insert Beg 2.Insert End 3.Insert After 4.Display 5.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: insertBeg(); break;
            case 2: insertEnd(); break;
            case 3: insertAfter(); break;
            case 4: display(); break;
            case 5: exit(0);
        }
    }
}