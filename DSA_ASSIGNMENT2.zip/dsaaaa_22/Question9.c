/*9.	Write a C program to represent and 
evaluate a Polynomial using a Linked List. Each node should 
represent a term containing coefficient and exponent.*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

struct node{
    int coeff,exp;
    struct node* next;
};

struct node* head=NULL;

void insert(){
    int c,e;
    printf("Enter coefficient and exponent: ");
    scanf("%d%d",&c,&e);

    struct node* newnode=malloc(sizeof(struct node));
    newnode->coeff=c;
    newnode->exp=e;
    newnode->next=head;
    head=newnode;
}

void display(){
    struct node* temp=head;
    printf("Polynomial: ");
    while(temp!=NULL){
        printf("%dx^%d ",temp->coeff,temp->exp);
        temp=temp->next;
    }
    printf("\n");
}

void evaluate(){
    int x,sum=0;
    printf("Enter value of x: ");
    scanf("%d",&x);

    struct node* temp=head;
    while(temp!=NULL){
        sum += temp->coeff * pow(x,temp->exp);
        temp=temp->next;
    }
    printf("Result = %d\n",sum);
}

int main(){
    int ch;

    while(1){
        printf("\n1.Insert Term 2.Display 3.Evaluate 4.Exit");
        printf("\nEnter choice: ");
        scanf("%d",&ch);

        switch(ch){
            case 1: insert(); break;
            case 2: display(); break;
            case 3: evaluate(); break;
            case 4: exit(0);
        }
    }
}