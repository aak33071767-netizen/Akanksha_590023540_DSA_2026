/*6.	Write a C program to represent a graph using an adjacency matrix. The program should perform Depth First Search (DFS) traversal starting from a given source vertex. The program should:
(i)	Accept the number of vertices n.
(ii)	Accept the adjacency matrix of the graph.
(iii)	 Accept a starting vertex for traversal.
(iv)	 Perform DFS traversal using recursion or stack.
(v)	Display the order of traversal of vertices.
*/
#include <stdio.h>
int adj[10][10], visited[10], n;
void dfs(int v) {
    printf("%d ", v);
    visited[v] = 1;

    for(int i=0;i<n;i++) {
        if(adj[v][i] == 1 && visited[i] == 0)
            dfs(i);
    }
}
int main() {
    int start;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for(int i=0;i<n;i++)
        for(int j=0;j<n;j++)
            scanf("%d", &adj[i][j]);

    printf("Enter starting vertex: ");
    scanf("%d", &start);

    printf("DFS Traversal: ");
    dfs(start);

    return 0;
}