/*3.	Write a C program to accept the number of vertices and edges of a graph and represent it using an adjacency matrix. The program should:
(i)	construct and display the adjacency matrix.
(ii)	Implement functions to calculate and print the in-degree and out-degree of a given vertex.
*/
#include <stdio.h>

int main() {
    int n, adj[10][10], i, j, vertex;
    int indeg = 0, outdeg = 0;

    printf("Enter number of vertices: ");
    scanf("%d", &n);

    printf("Enter adjacency matrix:\n");
    for(i=0;i<n;i++)
        for(j=0;j<n;j++)
            scanf("%d", &adj[i][j]);

    printf("\nAdjacency Matrix:\n");
    for(i=0;i<n;i++) {
        for(j=0;j<n;j++)
            printf("%d ", adj[i][j]);
        printf("\n");
    }

    printf("Enter vertex: ");
    scanf("%d", &vertex);

    for(i=0;i<n;i++) {
        if(adj[i][vertex] == 1)
            indeg++;
        if(adj[vertex][i] == 1)
            outdeg++;
    }

    printf("In-degree: %d\n", indeg);
    printf("Out-degree: %d\n", outdeg);

    return 0;
}