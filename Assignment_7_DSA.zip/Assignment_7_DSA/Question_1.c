/*1.	Write a C program to implement a hash function on student SAP-ID and categorize them in to their 10 families based on the last three digits. Example: Student with SAP-ID 5000423 belongs to family 9 and student with SAP-ID 5000425 belongs to family 2 based on last three digits.
*/
#include <stdio.h>

int hashFunction(int sapid) {
    int last3 = sapid % 1000;
    return last3 % 10;
}

int main() {
    int sapid;

    printf("Enter SAP ID: ");
    scanf("%d", &sapid);

    int family = hashFunction(sapid);

    printf("Student belongs to Family: %d\n", family);

    return 0;
}