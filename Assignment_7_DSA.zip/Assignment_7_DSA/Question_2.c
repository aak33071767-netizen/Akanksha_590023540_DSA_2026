/*2.	Write a C program to implement a Hash table using arrays. Perform Insert, Delete and Search operations on the hash table using the above Hash function (S.No.1). Adopt a suitable user-defined exception handling strategy if collision occurs while inserting data.*/
#include <stdio.h>
#define SIZE 10
int hashTable[SIZE];
void init() {
    for(int i=0;i<SIZE;i++)
        hashTable[i] = -1;
}
int hashFunction(int key) {
    return (key % 1000) % 10;
}
void insert(int key) {
    int index = hashFunction(key);

    int start = index;
    while(hashTable[index] != -1) {
        index = (index + 1) % SIZE;
        if(index == start) {
            printf("Hash Table Full!\n");
            return;
        }
    }
    hashTable[index] = key;
    printf("Inserted successfully\n");
}
void search(int key) {
    int index = hashFunction(key);
    int start = index;

    while(hashTable[index] != -1) {
        if(hashTable[index] == key) {
            printf("Element found at index %d\n", index);
            return;
        }
        index = (index + 1) % SIZE;
        if(index == start) break;
    }
    printf("Element not found\n");
}
void deleteKey(int key) {
    int index = hashFunction(key);
    int start = index;

    while(hashTable[index] != -1) {
        if(hashTable[index] == key) {
            hashTable[index] = -1;
            printf("Deleted successfully\n");
            return;
        }
        index = (index + 1) % SIZE;
        if(index == start) break;
    }
    printf("Element not found\n");
}
void display() {
    printf("Hash Table:\n");
    for(int i=0;i<SIZE;i++)
        printf("%d -> %d\n", i, hashTable[i]);
}
int main() {
    int choice, key;
    init();

    while(1) {
        printf("\n1.Insert 2.Delete 3.Search 4.Display 5.Exit\n");
        scanf("%d", &choice);

        switch(choice) {
            case 1:
                printf("Enter key: ");
                scanf("%d", &key);
                insert(key);
                break;
            case 2:
                printf("Enter key: ");
                scanf("%d", &key);
                deleteKey(key);
                break;
            case 3:
                printf("Enter key: ");
                scanf("%d", &key);
                search(key);
                break;
            case 4:
                display();
                break;
            case 5:
                return 0;
        }
    }
}